const GRAYSCALE_CSS = `
  img, canvas, video, svg, [style*="background-image"], [style*="background"] {
    filter: grayscale(100%) !important;
    -webkit-filter: grayscale(100%) !important;
  }
`;

const grayscaleTabs = new Map();  // tabId -> boolean

async function toggleGrayscale(tabId) {
  const isActive = grayscaleTabs.get(tabId) || false;

  try {
    if (isActive) {
      await chrome.scripting.removeCSS({
        target: { tabId, allFrames: true },
        css: GRAYSCALE_CSS,
      });
    } else {
      await chrome.scripting.insertCSS({
        target: { tabId, allFrames: true },
        css: GRAYSCALE_CSS,
      });
    }
    grayscaleTabs.set(tabId, !isActive);
  } catch (e) {
    console.warn("Grayscale toggle error:", e);
  }
}

// Context menu
chrome.contextMenus.create({
  id: "grayscale-toggle",
  title: "Convert images to grayscale",
  contexts: ["page", "selection"],
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "grayscale-toggle" && tab?.id) {
    toggleGrayscale(tab.id);
  }
});

// Toolbar button
chrome.action.onClicked.addListener((tab) => {
  if (tab?.id) toggleGrayscale(tab.id);
});

// Keyboard shortcut
chrome.commands.onCommand.addListener((command, tab) => {
  if (command === "toggle-grayscale" && tab?.id) {
    toggleGrayscale(tab.id);
  }
});

// Clean up closed tabs
chrome.tabs.onRemoved.addListener((tabId) => {
  grayscaleTabs.delete(tabId);
});
