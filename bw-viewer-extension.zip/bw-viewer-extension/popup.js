document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('toggle');

  // Load current state
  chrome.storage.sync.get('bwEnabled', (data) => {
    toggle.checked = !!data.bwEnabled;
  });

  // On toggle, send message + persist
  toggle.addEventListener('change', () => {
    const enabled = toggle.checked;
    chrome.storage.sync.set({ bwEnabled: enabled });
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'toggle-bw', enabled });
      }
    });
  });
});
