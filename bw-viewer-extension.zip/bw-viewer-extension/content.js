(() => {
  const BW_CLASS = 'fln-bw-active';

  // Inject CSS once
  const style = document.createElement('style');
  style.textContent = `
    html.${BW_CLASS} {
      filter: grayscale(100%) !important;
      -webkit-filter: grayscale(100%) !important;
    }
    html.${BW_CLASS} img,
    html.${BW_CLASS} video,
    html.${BW_CLASS} canvas {
      filter: grayscale(100%) !important;
      -webkit-filter: grayscale(100%) !important;
    }
  `;
  document.documentElement.appendChild(style);

  function setBW(enabled) {
    if (enabled) {
      document.documentElement.classList.add(BW_CLASS);
    } else {
      document.documentElement.classList.remove(BW_CLASS);
    }
  }

  // Read persisted state and apply
  chrome.storage.sync.get('bwEnabled', (data) => {
    setBW(!!data.bwEnabled);
  });

  // Listen for toggle messages from popup
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'toggle-bw') {
      setBW(msg.enabled);
    }
  });
})();
